package com.votingsystem.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "elections")
public class Election {

    @Id
    @GeneratedValue(generator="elec_seq")
    @SequenceGenerator(
            name = "elec_seq",
            sequenceName = "elec_SEQ",
            allocationSize = 1,
            initialValue = 5000   // First election id = 5000 (you can change)
    )
    @Column(name = "election_id")
    private int id;

    @Column(length = 50, name = "election_title", nullable = false)
    private String title;

    @Column(name = "start_time")
    private LocalDateTime startAt;

    @Column(name = "end_time")
    private LocalDateTime endAt;

    @Column(name = "is_active")
    private boolean active;

    @OneToMany(mappedBy = "election")
    @JsonIgnore
    private List<Candidate> candidates;

    @OneToMany(mappedBy = "election")
    @JsonIgnore
    private List<Vote> votes;

    // ------------------ GETTERS & SETTERS ------------------

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public LocalDateTime getStartAt() {
        return startAt;
    }

    public void setStartAt(LocalDateTime startAt) {
        this.startAt = startAt;
    }

    public LocalDateTime getEndAt() {
        return endAt;
    }

    public void setEndAt(LocalDateTime endAt) {
        this.endAt = endAt;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}

package com.votingsystem.controller;

import com.votingsystem.entity.Admin;
import com.votingsystem.service.AdminService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admins")
@CrossOrigin(origins = "http://localhost:4200")   // your Angular frontend
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    // -------------------- REGISTER ADMIN (OPTIONAL) --------------------
    // You can use this once to create an admin or insert directly in DB
    @PostMapping("/register")
    public ResponseEntity<Admin> register(@RequestBody Admin admin) {
        Admin saved = adminService.register(admin);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    // DTO for login request
    public static class AdminLoginRequest {
        public String email;
        public String password;
    }

    // -------------------- LOGIN ADMIN --------------------
    @PostMapping("/login")
    public ResponseEntity<Admin> login(@RequestBody AdminLoginRequest request) {
        Admin admin = adminService.login(request.email, request.password);
        return ResponseEntity.ok(admin);
    }
}

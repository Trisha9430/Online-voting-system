package com.votingsystem.service;

import com.votingsystem.entity.Admin;
import com.votingsystem.repository.AdminRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {

    private final AdminRepository adminRepository;

    public AdminService(AdminRepository adminRepository) {
        this.adminRepository = adminRepository;
    }

    // REGISTER NEW ADMIN (optional – you can also insert admin from SQL)
    public Admin register(Admin admin) {
        return adminRepository.save(admin);
    }

    // LOGIN ADMIN
    public Admin login(String email, String password) {
        return adminRepository
                .findByEmailAndPassword(email, password)
                .orElseThrow(() -> new RuntimeException("Invalid admin email or password"));
    }

    // Just in case you want to see all admins later
    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }
}

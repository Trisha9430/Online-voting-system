package com.votingsystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.votingsystem.entity.Election;

public interface ElectionRepository extends JpaRepository<Election, Integer> {
	List<Election> findByActiveTrue();

}

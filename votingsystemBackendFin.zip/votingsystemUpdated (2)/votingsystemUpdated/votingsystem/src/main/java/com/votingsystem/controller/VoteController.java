package com.votingsystem.controller;

import org.springframework.web.bind.annotation.*;

import com.votingsystem.service.VoteService;

@RestController
@RequestMapping("/api/votes")
@CrossOrigin
public class VoteController {

    private final VoteService voteService;

    public VoteController(VoteService voteService) {
        this.voteService = voteService;
    }

    // CAST VOTE
    @PostMapping("/cast")
    public String castVote(
            @RequestParam Integer voterId,
            @RequestParam Integer candidateId,
            @RequestParam Integer electionId
    ) {
        voteService.castVote(voterId, candidateId, electionId);
        return "Vote cast successfully!";
    }
    @GetMapping("/candidate/{candidateId}")
    public String getVotesByCandidate(@PathVariable Integer candidateId) {

        long count = voteService.getVotesForCandidate(candidateId);

        if (count == 0) {
            return "No one has voted for candidate " + candidateId + " yet.";
        }

        return "Total votes for candidate " + candidateId + ": " + count;
    }
    @GetMapping("/election/{electionId}")
    public String getVotesByElection(@PathVariable Integer electionId) {
        int count = voteService.getVotesForElection(electionId);

        if (count == 0) {
            return "No votes have been cast in election " + electionId + " yet.";
        }

        return "Total votes in election " + electionId + ": " + count;
    }

}

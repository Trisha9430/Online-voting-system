package com.votingsystem.service;

import org.springframework.stereotype.Service;
import java.util.List;

import com.votingsystem.entity.Voter;
import com.votingsystem.repository.VoterRepository;
import com.votingsystem.exception.BadRequestException;
import com.votingsystem.exception.ResourceNotFoundException;

@Service
public class VoterService {

    private final VoterRepository voterRepository;

    public VoterService(VoterRepository voterRepository) {
        this.voterRepository = voterRepository;
    }

    // -------- REGISTER --------
    public Voter register(Voter voter) {
        if (voterRepository.existsByEmail(voter.getEmail())) {
            throw new BadRequestException("Email already exists!");
        }
        return voterRepository.save(voter);
    }

    // -------- LOGIN --------
    public Voter login(String email, String password) {
        Voter voter = voterRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Email not found"));

        if (!voter.getPassword().equals(password)) {
            throw new RuntimeException("Invalid password");
        }

        return voter;
    }


    // -------- GET ALL --------
    public List<Voter> getAll() {
        return voterRepository.findAll();
    }

    // -------- GET ONE --------
    public Voter getById(Integer id) {
        return voterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Voter not found"));
    }

    // -------- UPDATE --------
    public Voter update(Integer id, Voter updated) {
        Voter v = getById(id);

        v.setName(updated.getName());
        v.setEmail(updated.getEmail());
        v.setPhone(updated.getPhone());

        if (updated.getPassword() != null) {
            v.setPassword(updated.getPassword());
        }

        return voterRepository.save(v);
    }

    // -------- DELETE --------
    public void delete(Integer id) {
        Voter v = getById(id);
        voterRepository.delete(v);
    }
}

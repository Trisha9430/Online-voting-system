package com.votingsystem.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;

import com.votingsystem.entity.Candidate;
import com.votingsystem.service.CandidateService;

@RestController
@RequestMapping("/api/candidates")
@CrossOrigin(origins = "http://localhost:4200")
public class CandidateController {

    private final CandidateService candidateService;

    public CandidateController(CandidateService candidateService) {
        this.candidateService = candidateService;
    }

    // ADD candidate to election
    @PostMapping("/add/{electionId}")
    public Candidate addCandidate(
            @PathVariable Integer electionId,
            @RequestBody Candidate candidate) {

        return candidateService.addCandidate(electionId, candidate);
    }

    // GET ALL
    @GetMapping("/all")
    public List<Candidate> getAll() {
        return candidateService.getAll();
    }

    // GET ONE
    @GetMapping("/{id}")
    public Candidate getById(@PathVariable Integer id) {
        return candidateService.getById(id);
    }

    // UPDATE
    @PutMapping("/{id}")
    public Candidate update(@PathVariable Integer id, @RequestBody Candidate updated) {
        return candidateService.update(id, updated);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Integer id) {
        candidateService.delete(id);
        return "Candidate deleted successfully!";
    }
    @GetMapping("/by-election/{electionId}")
    public List<Candidate> getCandidatesByElection(@PathVariable Integer electionId) {
        return candidateService.getByElection(electionId);
    }

}

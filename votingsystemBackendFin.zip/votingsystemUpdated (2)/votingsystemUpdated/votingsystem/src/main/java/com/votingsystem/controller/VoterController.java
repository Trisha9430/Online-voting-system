package com.votingsystem.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;

import com.votingsystem.dto.LoginDto;
import com.votingsystem.entity.Voter;
import com.votingsystem.service.VoterService;

@RestController
@RequestMapping("/api/voters")
@CrossOrigin
public class VoterController {

    private final VoterService voterService;

    public VoterController(VoterService voterService) {
        this.voterService = voterService;
    }

    // REGISTER
    @PostMapping("/register")
    public Voter register(@RequestBody Voter voter) {
        return voterService.register(voter);
    }

    // LOGIN
    @PostMapping("/login")
    public Voter login(@RequestBody LoginDto loginDto) {
        return voterService.login(loginDto.getEmail(), loginDto.getPassword());
    }

    // GET ALL
    @GetMapping("/all")
    public List<Voter> getAll() {
        return voterService.getAll();
    }

    // GET ONE
    @GetMapping("/{id}")
    public Voter getById(@PathVariable Integer id) {
        return voterService.getById(id);
    }

    // UPDATE
    @PutMapping("/{id}")
    public Voter update(@PathVariable Integer id, @RequestBody Voter updated) {
        return voterService.update(id, updated);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Integer id) {
        voterService.delete(id);
        return "Voter deleted successfully!";
    }
}

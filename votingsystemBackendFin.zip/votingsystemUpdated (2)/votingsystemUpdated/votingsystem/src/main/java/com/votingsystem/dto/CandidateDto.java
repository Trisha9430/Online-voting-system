package com.votingsystem.dto;

import jakarta.validation.constraints.*;

public class CandidateDto {
    @NotBlank @Size(min = 3, max = 30)
    private String name;

    @NotBlank @Size(min = 1, max = 15)
    private String party;

    @NotNull
    private Long electionId;

    public CandidateDto() {}

    // getters/setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getParty() { return party; }
    public void setParty(String party) { this.party = party; }

    public Long getElectionId() { return electionId; }
    public void setElectionId(Long electionId) { this.electionId = electionId; }
}

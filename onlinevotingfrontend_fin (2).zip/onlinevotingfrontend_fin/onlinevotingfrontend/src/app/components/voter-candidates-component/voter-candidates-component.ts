import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateService } from '../../services/candidate-service';
import { ChangeDetectorRef } from '@angular/core';

import { VoteService } from '../../services/vote-service';

@Component({
  selector: 'app-voter-candidates-component',
  standalone: false,
  templateUrl: './voter-candidates-component.html',
  styleUrl: './voter-candidates-component.css',
})
export class VoterCandidatesComponent implements OnInit{
electionId!: number;
  voterId!: number;
candidates: any[] = [];
 message: string = '';
  hasVoted: boolean = false;
  constructor(private route: ActivatedRoute,private router: Router,private candidateService: CandidateService,private voteService: VoteService, private cdr: ChangeDetectorRef) {}

   ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.electionId = Number(params.get('electionId'));
      this.voterId = Number(params.get('voterId'));
      this.loadCandidates();
    });
  }
  loadCandidates() {
    this.candidateService
      .getCandidatesByElection(this.electionId)
      .subscribe({
        next: (data) => {
          this.candidates = data;
          this.cdr.detectChanges();
        },
        error: (err) => {
          console.error('Error fetching candidates', err);
        }
      });
  }
 vote(candidateId: number) {
  if (this.hasVoted) {
    this.message = 'You have already voted!';
    return;
  }

  this.voteService
    .castVote(this.voterId, candidateId, this.electionId)
    .subscribe({
      next: () => {
        this.message = 'You have successfully voted!';
        this.hasVoted = true;
      },
      error: (err: any) => {   // ✅ typed
        this.message = err.error?.message || 'Failed to submit vote';
      }
    });
}



  goBackToDashboard() {
    this.router.navigate(['/voter-dashboard', this.voterId]);
}
}

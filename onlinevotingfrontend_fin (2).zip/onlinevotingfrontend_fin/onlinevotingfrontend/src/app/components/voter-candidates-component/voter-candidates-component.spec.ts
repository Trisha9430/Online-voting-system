import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoterCandidatesComponent } from './voter-candidates-component';

describe('VoterCandidatesComponent', () => {
  let component: VoterCandidatesComponent;
  let fixture: ComponentFixture<VoterCandidatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VoterCandidatesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VoterCandidatesComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

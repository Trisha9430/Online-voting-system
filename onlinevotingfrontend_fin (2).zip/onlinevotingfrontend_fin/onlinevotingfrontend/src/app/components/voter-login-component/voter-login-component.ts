import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { VoterService } from '../../services/voter-service';
import { VoterModel } from '../../models/voter-model/voter-model';

@Component({
  selector: 'app-voter-login-component',
  standalone: false,
  templateUrl: './voter-login-component.html',
  styleUrl: './voter-login-component.css',
})
export class VoterLoginComponent {
  email: string = '';
  password: string = '';
  message: string = ''; 
  errorMessage: string = '';

  constructor(private voterService: VoterService, private router: Router) {}

  login() {
  this.voterService.login(this.email, this.password)
    .subscribe({
      next: (response) => {
        this.message = "Login successful! Redirecting...";

        const voterId = response.id; // ✅ VERY IMPORTANT

        setTimeout(() => {
          this.router.navigate(['/voter-dashboard', voterId]);
        }, 1000);
      },
      error: () => {
        this.message = "Invalid email or password";
      }
    });
}

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  isRegistered: boolean = false;

  constructor() {
    // Check if voter is already registered (based on localStorage)
    const voterId = localStorage.getItem("voterId");
    this.isRegistered = !!voterId; // true if exists, false if not
  }
}

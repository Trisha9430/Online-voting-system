import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CandidateService } from '../../services/candidate-service';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateModel } from '../../models/candidate-model/candidate-model';

@Component({
  selector: 'app-admin-candidates-component',
  standalone: false,
  templateUrl: './admin-candidates-component.html',
  styleUrl: './admin-candidates-component.css',
})
export class AdminCandidatesComponent implements OnInit {

  candidates: CandidateModel[] = [];
  electionId: number=0;
  message = '';

  constructor(
    private candidateService: CandidateService,
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
  this.electionId = Number(this.route.snapshot.paramMap.get("id"));
  this.loadCandidates();
}

loadCandidates() {
    this.candidateService.getByElection(this.electionId).subscribe({
      next: (data: CandidateModel[]) => {
        console.log('API response:', data);

        this.candidates = [...data];   // 🔥 create new reference
        this.cdr.detectChanges();      // 🔥 force UI refresh
      },
      error: () => {
        this.message = "Failed to load candidates";
      }
    });
  }

  addCandidate() {
    this.router.navigate([`/admin/elections/${this.electionId}/candidates/add`]);
  }

  deleteCandidate(id?: number) {
    if (!id) return;

    this.candidateService.delete(id).subscribe({
      next: () => this.loadCandidates(),
      error: () => console.log("Delete failed")
    });
  }
}

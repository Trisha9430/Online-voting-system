import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCandidatesComponent } from './admin-candidates-component';

describe('AdminCandidatesComponent', () => {
  let component: AdminCandidatesComponent;
  let fixture: ComponentFixture<AdminCandidatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdminCandidatesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminCandidatesComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

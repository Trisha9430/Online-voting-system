import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ElectionModel } from '../../models/election-model/election-model';
import { ActivatedRoute, Router } from '@angular/router';
import { ElectionService } from '../../services/election-service';

@Component({
  selector: 'app-voter-dashboard-component',
  standalone: false,
  templateUrl: './voter-dashboard-component.html',
  styleUrl: './voter-dashboard-component.css',
})
export class VoterDashboardComponent implements OnInit {
voterId: number = 0;
  elections: any[] = [];
  message = '';

  constructor(
    private electionService: ElectionService,
    private route: ActivatedRoute,
    private router: Router,
    private cd:ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.voterId = Number(this.route.snapshot.paramMap.get('id'));
    this.loadActiveElections();
  }

  loadActiveElections() {
  this.electionService.getAll().subscribe({
    next: (data) => {
      // Filter active elections from ALL elections
      this.elections = data.filter(e => e.active === true);
      this.cd.detectChanges();

    },
    error: () => {
      this.message = "Failed to load elections";
    }
  });
}

viewCandidates(electionId: number | undefined) {
  if (!electionId) {
    console.error('Election ID is undefined', electionId);
    return;
  }

  this.router.navigate([
    '/voter-candidates',
    this.voterId,
    electionId
  ]);
}


}

import { Component } from '@angular/core';
import { VoterModel } from '../../models/voter-model/voter-model';
import { VoterService } from '../../services/voter-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-voter-register-component',
  standalone: false,
  templateUrl: './voter-register-component.html',
  styleUrl: './voter-register-component.css',
})
export class VoterRegisterComponent {
  voter: VoterModel = {
    name: '',
    email: '',
    password: '',
    phone: ''
  };

  message: string = '';

  constructor(private voterService: VoterService, private router: Router) {}

  register() {
  this.voterService.register(this.voter).subscribe({
    next: (data) => {
      alert("Registration Successful! Please login now.");

      // redirect to login page
      this.router.navigate(['/voter/login']);
    },
    error: (err) => {
      console.error(err);
      alert("Registration Failed! Try again.");
    }
  });
}
}
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminElectionsComponent } from './admin-elections-component';

describe('AdminElectionsComponent', () => {
  let component: AdminElectionsComponent;
  let fixture: ComponentFixture<AdminElectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdminElectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminElectionsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

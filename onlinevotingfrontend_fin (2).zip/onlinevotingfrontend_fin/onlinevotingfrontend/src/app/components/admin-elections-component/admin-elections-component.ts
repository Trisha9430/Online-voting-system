import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ElectionService } from '../../services/election-service';
import { ElectionModel } from '../../models/election-model/election-model';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-admin-elections-component',
  standalone: false,
  templateUrl: './admin-elections-component.html',
  styleUrl: './admin-elections-component.css',
})
export class AdminElectionsComponent implements OnInit {

  elections: ElectionModel[] = [];
  message: string = '';

  constructor(
    private service: ElectionService,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.message = params['msg'] || '';
    });

    this.loadElections();
  }

  loadElections() {
    this.service.getAll().subscribe({
      next: (data) => {
        console.log("Loaded elections:", data);
        this.elections = data;
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error("Error loading elections:", error);
      }
    });
  }

  addElection() {
    this.router.navigate(['/admin/elections/add']);
  }

  editElection(id: number) {
    this.router.navigate(['/admin/elections/update', id]);
  }

  deleteElection(id: number) {
    if (!confirm("Are you sure you want to delete this election?")) return;

    this.service.delete(id).subscribe({
      next: () => {
        this.message = "Election deleted successfully!";
        this.loadElections();
      },
      error: () => this.message = "Failed to delete election"
    });
  }

  manageCandidates(id: number) {
    this.router.navigate([`/admin/elections/${id}/candidates`]);
  }
}

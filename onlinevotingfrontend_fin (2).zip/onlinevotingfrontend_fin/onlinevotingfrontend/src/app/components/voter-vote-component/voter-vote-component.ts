import { Component, OnInit } from '@angular/core';
import { CandidateModel } from '../../models/candidate-model/candidate-model';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateService } from '../../services/candidate-service';
import { VoteService } from '../../services/vote-service';



@Component({
  selector: 'app-voter-vote-component',
  standalone: false,
  templateUrl: './voter-vote-component.html',
  styleUrl: './voter-vote-component.css',
})
export class VoterVoteComponent implements OnInit {
  voterId: number = 0;
  electionId: number = 0;
  candidates: CandidateModel[] = [];
  message: string = '';

  constructor(
    private route: ActivatedRoute,
    private candidateService: CandidateService,
    private voteService: VoteService,
    private router: Router
    

  ) {}

  ngOnInit(): void {
  this.voterId = Number(this.route.snapshot.paramMap.get('voterId'));
  this.electionId = Number(this.route.snapshot.paramMap.get('electionId'));

  this.loadCandidates();
}

loadCandidates() {
  this.candidateService
    .getCandidatesByElection(this.electionId)
    .subscribe({
      next: data => this.candidates = data,
      error: () => this.message = 'Failed to load candidates'
    });
}


  vote(candidateId: number | undefined) {
  if (!candidateId) return;

  this.voteService.castVote(this.voterId, candidateId, this.electionId)
    .subscribe({
      next: () => {
        this.message = "Vote submitted successfully!";
        setTimeout(() => {
          this.router.navigate(['/voter-results', this.electionId]);
        }, 1500);
      },
      error: err => {
        this.message = err.error?.messages?.[0] || 'Failed to submit vote';
      }
    });
}

}


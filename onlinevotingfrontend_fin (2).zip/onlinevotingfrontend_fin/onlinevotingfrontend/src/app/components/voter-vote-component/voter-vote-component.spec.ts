import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoterVoteComponent } from './voter-vote-component';

describe('VoterVoteComponent', () => {
  let component: VoterVoteComponent;
  let fixture: ComponentFixture<VoterVoteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VoterVoteComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VoterVoteComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ElectionService } from '../../services/election-service';
import { ElectionModel } from '../../models/election-model/election-model';

@Component({
  selector: 'app-admin-add-election-component',
  standalone: false,
  templateUrl: './admin-add-election-component.html',
  styleUrls: ['./admin-add-election-component.css'],
})
export class AdminAddElectionComponent {

  election: ElectionModel = {
    id: 0,
    title: '',
    startAt: '',
    endAt: '',
    active: false
  };

  message: string = '';

  constructor(
    private electionService: ElectionService,
    private router: Router
  ) {}

  // save() {

  //   // Add seconds to datetime if missing
  //   if (this.election.startAt.length === 16) {
  //     this.election.startAt += ":00";
  //   }
  //   if (this.election.endAt.length === 16) {
  //     this.election.endAt += ":00";
  //   }

  //   this.electionService.create(this.election).subscribe({
  //     next: () => {
  //       this.router.navigate(
  //         ['/admin/elections'],
  //         { queryParams: { msg: 'Election created successfully!' } }
  //       );
  //     },
  //     error: () => {
  //       this.message = 'Failed to create election';
  //     }
  //   });
  // }
  save() {

  // Validate
  if (!this.election.title || !this.election.startAt || !this.election.endAt) {
    this.message = "All fields are required!";
    return;
  }

  // Format date-time: add seconds
  this.election.startAt = this.election.startAt.padEnd(19, ":00");
  this.election.endAt = this.election.endAt.padEnd(19, ":00");

  // Auto activate
  this.election.active = true;

  this.electionService.create(this.election).subscribe({
    next: () => {
      // Optional: Show message before redirect
      this.message = "Election created successfully!";

      setTimeout(() => {
        this.router.navigate(
          ['/admin/elections'],
          { queryParams: { msg: 'Election created successfully!' } }
        );
      }, 1000);
    },
    error: () => {
      this.message = "Failed to create election";
    }
  });
}

}

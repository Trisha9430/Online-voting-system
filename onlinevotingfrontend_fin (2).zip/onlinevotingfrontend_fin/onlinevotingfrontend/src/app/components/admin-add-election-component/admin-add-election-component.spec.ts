import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAddElectionComponent } from './admin-add-election-component';

describe('AdminAddElectionComponent', () => {
  let component: AdminAddElectionComponent;
  let fixture: ComponentFixture<AdminAddElectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdminAddElectionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminAddElectionComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { CandidateService } from '../../services/candidate-service';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateModel } from '../../models/candidate-model/candidate-model';

@Component({
  selector: 'app-admin-add-candidate-component',
  standalone: false,
  templateUrl: './admin-add-candidate-component.html',
  styleUrl: './admin-add-candidate-component.css',
})
export class AdminAddCandidateComponent implements OnInit {

  electionId: number = 0;   // ✅ FIX: Declare electionId here

  candidate: CandidateModel = {
    candId: 0,
    name: '',
    party: '',
    electionId: 0
  };

  message = '';

  constructor(
    private candidateService: CandidateService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // ✅ Read election ID from URL
    this.electionId = Number(this.route.snapshot.paramMap.get("id"));
    this.candidate.electionId = this.electionId;
  }

  // 
  save() {
    this.candidateService.addCandidate(this.electionId, this.candidate).subscribe({
      next: () => {
        this.message = "Candidate added successfully!";

        setTimeout(() => {
          this.router.navigate([`/admin/elections/${this.electionId}/candidates`]);
        }, 1200);
      },
      error: () => {
        this.message = "Failed to add candidate.";
      }
    });
  }
}

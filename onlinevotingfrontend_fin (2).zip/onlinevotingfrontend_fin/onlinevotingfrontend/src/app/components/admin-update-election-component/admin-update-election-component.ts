import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ElectionService } from '../../services/election-service';
import { ElectionModel } from '../../models/election-model/election-model';

@Component({
  selector: 'app-admin-update-election-component',
  standalone: false,
  templateUrl: './admin-update-election-component.html',
  styleUrl: './admin-update-election-component.css'
})
export class AdminUpdateElectionComponent implements OnInit {

  electionId = 0;

  election: ElectionModel = {
    id: 0,
    title: '',
    startAt: '',
    endAt: '',
    active: false
  };

  message = '';

  constructor(
    private route: ActivatedRoute,
    private service: ElectionService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.electionId = Number(this.route.snapshot.paramMap.get('id'));

    this.service.getById(this.electionId).subscribe({
      next: (data) => {
        this.election = data;

        // FIX: convert to datetime-local format
        if (data.startAt)
          this.election.startAt = data.startAt.substring(0, 16);

        if (data.endAt)
          this.election.endAt = data.endAt.substring(0, 16);
      },
      error: () => this.message = 'Failed to load election'
    });
  }

  update() {

    // Add seconds back for backend
    if (this.election.startAt.length === 16)
      this.election.startAt += ":00";

    if (this.election.endAt.length === 16)
      this.election.endAt += ":00";

    this.service.update(this.electionId, this.election).subscribe({
      next: () => {
        this.router.navigate(['/admin/elections'], {
          queryParams: { msg: 'Election updated successfully!' }
        });
      },
      error: () => this.message = 'Failed to update election'
    });
  }
}

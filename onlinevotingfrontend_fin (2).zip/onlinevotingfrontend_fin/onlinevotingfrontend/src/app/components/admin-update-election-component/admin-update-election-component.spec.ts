import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUpdateElectionComponent } from './admin-update-election-component';

describe('AdminUpdateElectionComponent', () => {
  let component: AdminUpdateElectionComponent;
  let fixture: ComponentFixture<AdminUpdateElectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdminUpdateElectionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminUpdateElectionComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

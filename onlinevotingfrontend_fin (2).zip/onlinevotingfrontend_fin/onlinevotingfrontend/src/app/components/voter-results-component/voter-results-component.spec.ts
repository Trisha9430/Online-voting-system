import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoterResultsComponent } from './voter-results-component';

describe('VoterResultsComponent', () => {
  let component: VoterResultsComponent;
  let fixture: ComponentFixture<VoterResultsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VoterResultsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VoterResultsComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

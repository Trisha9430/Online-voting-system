import { Component, OnInit } from '@angular/core';
import { CandidateModel } from '../../models/candidate-model/candidate-model';
import { ActivatedRoute } from '@angular/router';
import { CandidateService } from '../../services/candidate-service';
import { VoteService } from '../../services/vote-service';

@Component({
  selector: 'app-voter-results-component',
  standalone: false,
  templateUrl: './voter-results-component.html',
  styleUrl: './voter-results-component.css',
})
export class VoterResultsComponent implements OnInit {
electionId: number = 0;
  candidates: CandidateModel[] = [];
  results: { candidateId: number, votes: number }[] = [];
  message: string = '';

  constructor(
    private route: ActivatedRoute,
    private candidateService: CandidateService,
    private voteService: VoteService
  ) {}

  ngOnInit(): void {
    this.electionId = Number(this.route.snapshot.paramMap.get('id'));

    this.loadCandidates();
  }

  loadCandidates() {
  this.candidateService
    .getCandidatesByElection(this.electionId)
    .subscribe({
      next: data => {
        this.candidates = data;
        this.loadVotes();
      },
      error: () => this.message = 'Failed to load candidates'
    });
}


  loadVotes() {
    this.candidates.forEach(c => {
      this.voteService.getVotesForCandidate(c.candId!).subscribe({
        next: (data) => {
          this.results.push({
            candidateId: c.candId!,
            votes: Number(data)
          });
        },
        error: () => {
          this.results.push({
            candidateId: c.candId!,
            votes: 0
          });
        }
      });
    });
  }

  getVotes(candidateId: number | undefined): number {
    if (!candidateId) return 0;
    return this.results.find(r => r.candidateId === candidateId)?.votes || 0;
  }

}
import { Component } from '@angular/core';
import { AdminModel } from '../../models/admin-model/admin-model';
import { AdminService } from '../../services/admin-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login-component',
  standalone: false,
  templateUrl: './admin-login-component.html',
  styleUrl: './admin-login-component.css',
})
export class AdminLoginComponent {
  email: string = '';
  password: string = '';
  message: string = '';

  constructor(private adminService: AdminService, private router: Router) {}

  login() {
    this.adminService.login(this.email, this.password).subscribe({
      next: (admin: AdminModel) => {
        this.message = 'Admin login successful! Redirecting...';

        localStorage.setItem('adminId', admin.id!.toString());

        setTimeout(() => {
          this.router.navigate(['/admin/dashboard']);
        }, 1500);
      },
      error: () => {
        this.message = 'Invalid admin credentials!';
      },
    });
  }
}

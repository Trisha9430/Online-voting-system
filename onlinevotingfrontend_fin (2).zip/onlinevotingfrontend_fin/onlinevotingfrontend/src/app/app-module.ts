import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { RouterModule } from "@angular/router";
import { AppRoutingModule } from "./app-routing-module";
import { App } from "./app";
import { Home } from "./components/home/home";
import { Navbar } from "./components/navbar/navbar";
import { VoterLoginComponent } from "./components/voter-login-component/voter-login-component";
import { VoterRegisterComponent } from "./components/voter-register-component/voter-register-component";
import { VoterVoteComponent } from "./components/voter-vote-component/voter-vote-component";
import { VoterResultsComponent } from "./components/voter-results-component/voter-results-component";
import { VoterDashboardComponent } from "./components/voter-dashboard-component/voter-dashboard-component";
import { AdminLoginComponent } from "./components/admin-login-component/admin-login-component";
import { AdminDashboardComponent } from "./components/admin-dashboard-component/admin-dashboard-component";
import { AdminElectionsComponent } from "./components/admin-elections-component/admin-elections-component";
import { AdminAddElectionComponent } from "./components/admin-add-election-component/admin-add-election-component";
import { AdminUpdateElectionComponent } from "./components/admin-update-election-component/admin-update-election-component";
import { AdminCandidatesComponent } from "./components/admin-candidates-component/admin-candidates-component";
import { AdminAddCandidateComponent } from "./components/admin-add-candidate-component/admin-add-candidate-component";
import { VoterCandidatesComponent } from './components/voter-candidates-component/voter-candidates-component';

@NgModule({
  declarations: [
    App,
    Home,
    Navbar,
    VoterLoginComponent,
    VoterRegisterComponent,
    VoterVoteComponent,
    VoterResultsComponent,
    VoterDashboardComponent,
    AdminLoginComponent,
    AdminDashboardComponent,
    AdminElectionsComponent,
    AdminAddElectionComponent,
    AdminUpdateElectionComponent,
    AdminCandidatesComponent,
    AdminAddCandidateComponent,
    VoterCandidatesComponent
  ],

  imports: [
    BrowserModule,
    FormsModule,
    CommonModule,
    RouterModule,
    AppRoutingModule

  ],

  providers: [],
  bootstrap: [App]
})
export class AppModule { }

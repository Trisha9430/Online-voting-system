import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoteModel } from './vote-model';

describe('VoteModel', () => {
  let component: VoteModel;
  let fixture: ComponentFixture<VoteModel>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VoteModel]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VoteModel);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

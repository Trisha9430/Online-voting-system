import { Component } from '@angular/core';

@Component({
  selector: 'app-vote-model',
  standalone: false,
  templateUrl: './vote-model.html',
  styleUrl: './vote-model.css',
})
export class VoteModel {
  id?: number;
  voterId!: number;
  candidateId!: number;
  electionId!: number;
}

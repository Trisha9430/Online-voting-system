import { Component } from '@angular/core';

@Component({
  selector: 'app-voter-model',
  standalone: false,
  templateUrl: './voter-model.html',
  styleUrl: './voter-model.css',
})
export class VoterModel {
  id?: number;
  name?: string;
  email?: string;
  password?: string;
  phone?: string;   // <-- THIS MUST BE PRESENT
}


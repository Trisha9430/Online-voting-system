import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoterModel } from './voter-model';

describe('VoterModel', () => {
  let component: VoterModel;
  let fixture: ComponentFixture<VoterModel>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VoterModel]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VoterModel);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-model',
  standalone: false,
  templateUrl: './admin-model.html',
  styleUrl: './admin-model.css',
})
export class AdminModel {
  id?: number;
  name!: string;
  email!: string;
  password!: string;
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateModel } from './candidate-model';

describe('CandidateModel', () => {
  let component: CandidateModel;
  let fixture: ComponentFixture<CandidateModel>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CandidateModel]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CandidateModel);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

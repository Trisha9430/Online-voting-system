export interface CandidateModel {
  candId?: number;
  name: string;
  party: string;
  electionId?: number;
}

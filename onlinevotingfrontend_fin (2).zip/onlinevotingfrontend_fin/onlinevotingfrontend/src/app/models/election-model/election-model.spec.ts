import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElectionModel } from './election-model';

describe('ElectionModel', () => {
  let component: ElectionModel;
  let fixture: ComponentFixture<ElectionModel>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ElectionModel]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ElectionModel);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

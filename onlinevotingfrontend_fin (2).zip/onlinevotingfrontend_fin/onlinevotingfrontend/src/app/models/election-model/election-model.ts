export interface ElectionModel {
  id: number;
  title: string;
  startAt: string;
  endAt: string;
  active: boolean;
}

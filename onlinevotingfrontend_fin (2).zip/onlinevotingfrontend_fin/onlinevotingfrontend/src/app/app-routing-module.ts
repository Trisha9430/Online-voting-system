import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VoterLoginComponent } from './components/voter-login-component/voter-login-component';
import { VoterRegisterComponent } from './components/voter-register-component/voter-register-component';
import { VoterDashboardComponent } from './components/voter-dashboard-component/voter-dashboard-component';
import { VoterVoteComponent } from './components/voter-vote-component/voter-vote-component';
import { VoterResultsComponent } from './components/voter-results-component/voter-results-component';
import { AdminLoginComponent } from './components/admin-login-component/admin-login-component';
import { AdminDashboardComponent } from './components/admin-dashboard-component/admin-dashboard-component';
import { AdminElectionsComponent } from './components/admin-elections-component/admin-elections-component';
import { AdminAddElectionComponent } from './components/admin-add-election-component/admin-add-election-component';
import { AdminUpdateElectionComponent } from './components/admin-update-election-component/admin-update-election-component';
import { AdminCandidatesComponent } from './components/admin-candidates-component/admin-candidates-component';
import { AdminAddCandidateComponent } from './components/admin-add-candidate-component/admin-add-candidate-component';
import { Home } from './components/home/home';
import { VoterCandidatesComponent } from './components/voter-candidates-component/voter-candidates-component';

const routes: Routes = [
  { path: '', component: Home },

  // Voter
  { path: 'voter/login', component: VoterLoginComponent },
  { path: 'voter/register', component: VoterRegisterComponent },
  { path: 'voter-dashboard/:id', component: VoterDashboardComponent },

  { path: 'voter-dashboard/:voterId', component: VoterDashboardComponent },

{ path: 'voter-candidates/:voterId/:electionId',
  component: VoterCandidatesComponent },

{ path: 'voter-vote/:voterId/:electionId/:candidateId',
  component: VoterVoteComponent },

{ path: 'voter-results/:id',
  component: VoterResultsComponent },


  // Admin
  { path: 'admin/login', component: AdminLoginComponent },
  { path: 'admin/dashboard', component: AdminDashboardComponent },
  { path: 'admin/elections', component: AdminElectionsComponent },
  { path: 'admin/elections/add', component: AdminAddElectionComponent },
  { path: 'admin/elections/update/:id', component: AdminUpdateElectionComponent },

  //{ path: 'admin/candidates', component: AdminCandidatesComponent },
  //{ path: 'admin/candidates/add/:electionId', component: AdminAddCandidateComponent },
  { path: "admin/elections/:id/candidates", component: AdminCandidatesComponent },
  { path: "admin/elections/:id/candidates/add", component: AdminAddCandidateComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

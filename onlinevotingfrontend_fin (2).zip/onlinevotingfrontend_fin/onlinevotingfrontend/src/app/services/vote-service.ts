import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class VoteService {
  private baseUrl = 'http://localhost:8080/api/votes';

  constructor(private http: HttpClient) {}

  // Cast vote
  castVote(voterId: number, candidateId: number, electionId: number) {

    const params = new HttpParams()
      .set('voterId', voterId)
      .set('candidateId', candidateId)
      .set('electionId', electionId);

    return this.http.post(
      `${this.baseUrl}/cast`,
      null,
      { params,
        responseType: 'text'
       }
    );
  }

  // Votes for a candidate
  getVotesForCandidate(candidateId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/candidate/${candidateId}`, { responseType: 'text' });
  }

  // Votes for an election
  getVotesForElection(electionId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/election/${electionId}`, { responseType: 'text' });
  }

}

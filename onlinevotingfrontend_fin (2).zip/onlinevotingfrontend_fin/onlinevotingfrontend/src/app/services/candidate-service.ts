import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CandidateModel } from '../models/candidate-model/candidate-model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CandidateService {

  private baseUrl = 'http://localhost:8080/api/candidates';

  constructor(private http: HttpClient) {}

  addCandidate(electionId: number, candidate: CandidateModel): Observable<CandidateModel> {
    return this.http.post<CandidateModel>(`${this.baseUrl}/add/${electionId}`, candidate);
  }

  getAll(): Observable<CandidateModel[]> {
    return this.http.get<CandidateModel[]>(`${this.baseUrl}/all`);
  }

  getByElection(id: number) {
    return this.http.get<any[]>(`${this.baseUrl}/by-election/${id}`);
  }

  delete(id: number) {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }
  getCandidatesByElection(electionId: number) {
  return this.http.get<any[]>(
    `http://localhost:8080/api/candidates/by-election/${electionId}`
  );
}


}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ElectionModel } from '../models/election-model/election-model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ElectionService {

  private baseUrl = 'http://localhost:8080/api/elections';

  constructor(private http: HttpClient) {}

  create(election: ElectionModel): Observable<ElectionModel> {
    return this.http.post<ElectionModel>(`${this.baseUrl}/create`, election);
  }

  getAll(): Observable<ElectionModel[]> {
  return this.http.get<ElectionModel[]>(`${this.baseUrl}/all`);
}

getActive(): Observable<ElectionModel[]> {
  return this.http.get<ElectionModel[]>(`${this.baseUrl}/active`);
}



  getById(id: number): Observable<ElectionModel> {
    return this.http.get<ElectionModel>(`${this.baseUrl}/${id}`);
  }

  update(id: number, election: ElectionModel): Observable<ElectionModel> {
    return this.http.put<ElectionModel>(`${this.baseUrl}/${id}`, election);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

}

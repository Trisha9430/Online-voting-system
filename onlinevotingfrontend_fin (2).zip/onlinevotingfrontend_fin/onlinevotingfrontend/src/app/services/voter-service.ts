import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { VoterModel } from '../models/voter-model/voter-model';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root',
})
export class VoterService {
  private baseUrl = 'http://localhost:8080/api/voters';

  constructor(private http: HttpClient) { }

  register(voter: VoterModel): Observable<VoterModel> {
    return this.http.post<VoterModel>(`${this.baseUrl}/register`, voter);
  }

  login(email: string, password: string): Observable<VoterModel> {
    return this.http.post<VoterModel>(`${this.baseUrl}/login`, { email, password });
  }

  getAll(): Observable<VoterModel[]> {
    return this.http.get<VoterModel[]>(`${this.baseUrl}/all`);
  }

  getById(id: number): Observable<VoterModel> {
    return this.http.get<VoterModel>(`${this.baseUrl}/${id}`);
  }
}

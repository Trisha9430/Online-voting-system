import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AdminModel } from '../models/admin-model/admin-model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  private baseUrl = 'http://localhost:8080/api/admins';

  constructor(private http: HttpClient) { }

  register(admin: AdminModel): Observable<AdminModel> {
    return this.http.post<AdminModel>(`${this.baseUrl}/register`, admin);
  }

  login(email: string, password: string): Observable<AdminModel> {
    return this.http.post<AdminModel>(`${this.baseUrl}/login`, { email, password });
  }
}

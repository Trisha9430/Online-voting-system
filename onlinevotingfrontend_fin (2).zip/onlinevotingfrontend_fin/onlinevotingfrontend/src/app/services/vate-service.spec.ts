import { TestBed } from '@angular/core/testing';

import { VateService } from './vate-service';

describe('VateService', () => {
  let service: VateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
